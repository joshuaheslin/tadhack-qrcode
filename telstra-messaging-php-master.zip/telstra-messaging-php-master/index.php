<!DOCTYPE html>
<html>
<head>
  <title>Send a SMS</title>
</head>
<body>
  <p>Enter a mobile number to receive the SMS, note the number can be in 04xxxxxxxx or +614xxxxxxxx formats</p>
  <form method="post" action="start.php">
    <input type="text" name="mobile"> 	
    <input type="submit" value="Send a SMS">
  </form>
</body>
</html>
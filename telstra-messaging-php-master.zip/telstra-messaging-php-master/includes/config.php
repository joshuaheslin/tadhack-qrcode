<?php

$config = array(
  "client_id"  => "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
  "client_secret"  => "xxxxxxxxxxxxxxxx",
);